#include <bits/stdc++.h>

using namespace std;

int main()
{
	unordered_map<string,double> probability; //take given probability
	probability["E"]=0.6;
	probability["S"]=0.4;
	probability["SE"]=0.7;
	probability["EE"]=0.3;
	probability["SS"]=0.4;
	probability["ES"]=0.6;
	probability["cojeloE"]=0.1;
	probability["cojeloS"]=0.3;
	probability["conE"]=0.2;
	probability["conS"]=0.3;
	probability["takeE"]=0.3;
	probability["takeS"]=0.15;
	probability["itE"]=0.2;
	probability["itS"]=0.15;
	probability["easyE"]=0.2;
	probability["easyS"]=0.1;
	vector<string> here;
	here.push_back("Cojelo Con Take It Easy");
	here.push_back("Con Take It Easy");
	here.push_back("Easy Con");
	here.push_back("Cojelo Easy Take It");
	for(int g=0; g<4; g++){
	string s;
    s= here[g];
	vector<string> input;  //stores the input string after space parsing
	string temp="";
	for(auto x : s){
		if(x==' '){
			input.push_back(temp);
			temp="";
		}
		else {
			temp+=tolower(x);  // convert all to lowercase
		}
	}
	input.push_back(temp);

	vector<pair<string, double>> ans; // stores the final answer
	// all the language strings present in ans have the same probability
	ans.push_back(make_pair("null", 0.0));
	int n=input.size();

	// total pow(2,n) combinations of E/S are to be checked
	for(int i=0; i<pow(2,n); i++){
		//i stores 4-bit numbers
		//0 gives S, 1 gives E
		//e.g. i=2 means i=0010 i.e. SSES

		string lang=""; // stores string for this given i
		double prob=1.0; // stores the probability for this given i
		char flag; // stores the letter for the given j
		for(int j=n-1; j>=0; j--){
			bool language = i & (1<<j);  //true if english, false if spanish
			if(language) flag='E';
			else flag='S';
			lang+=flag;
			string help1=""; //help1 gives string which helps to get the probability for the letter E/S
			string help2=""; //help2 gives string which helps to get the probability for the word n-1-j given E/S
			help2+=input[n-1-j];
			help2+=flag;
			if(j==n-1){
				// the first bit, for which help1 is only probability of that E/S
				help1+=flag;
				prob*=probability[help1];
				prob*=probability[help2];
			}
			else{
				help1+=flag;
				help1+=lang[lang.size()-2];
				prob*=probability[help1];
				prob*=probability[help2];
			}
		}

		if(ans[0].first=="null"){
			// when i=0
			ans.clear();
			ans.push_back(make_pair(lang, prob));
		}
		else{
			if(ans[0].second<prob){
				// only if prob excedes the current ans vector probability
				ans.clear();
				ans.push_back(make_pair(lang, prob));
			}
			else if(ans[0].second==prob){
				// only if prob equals the current ans vector probability
				ans.push_back(make_pair(lang, prob));
			}
		}
	}

	for(int i=0; i<ans.size(); i++){
		cout << "\"" << ans[i].first << "\":" << fixed << setprecision(5) << ans[i].second << endl;
	}
	}
return 0;
}
