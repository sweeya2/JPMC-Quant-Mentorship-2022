#!/usr/bin/env python
# coding: utf-8

# In[90]:


import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import norm
import math


# In[91]:


def getd1(St, t):
    return np.divide((np.log(St/50.0) + (0.12 + (0.3*0.3)/2.0)*(1.0-t)),(0.3*math.sqrt(1.0 - t)))


# In[92]:


def getd2(St, t):
    return getd1(St, t) - (0.3*math.sqrt(1.0-t))


# In[93]:


def call_price(St, t):
    return norm.cdf(getd1(St, t))*St - norm.cdf(getd2(St, t)) * 50.0 * math.exp(-0.12 *(1.0 - t))


# In[94]:


x=np.arange(1,101,1)
y=x


# In[95]:


y = call_price(x, 0.0)


# In[96]:


plt.plot(x,y)
plt.xlabel('Stock Price ($)')
plt.ylabel('BSM_price_call_t=0')
plt.show()


# In[77]:


y = call_price(x, 0.5)


# In[78]:


plt.plot(x,y)
plt.xlabel('Stock Price ($)')
plt.ylabel('BSM_price_call_t=0.5')
plt.show()


# In[79]:


y = call_price(x, 0.999999)


# In[80]:


plt.plot(x,y)
plt.xlabel('Stock Price ($)')
plt.ylabel('BSM_price_call_t=1')
plt.show()

