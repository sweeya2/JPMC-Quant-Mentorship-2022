#!/usr/bin/env python
# coding: utf-8

# In[14]:


from sympy.solvers import solve,nsolve,solveset
from sympy import Symbol,symbols,sin,pi,cos
import numpy as np
import math
import time


# In[3]:


from matplotlib import pyplot as plt 


# In[4]:


def truncate(num, n):
    integer = int(num * (10**n))/(10**n)
    return float(integer)


# In[5]:


def findalpha(AR):
    x = Symbol('x')
    return nsolve(2*float(AR)*(1-(float(pi))/4)-1+cos(x)-sin(x)+x,x, 1)


# In[6]:


def findn(AR):
    value = findalpha(AR);
    x = Symbol('x')
    ans = solve((x*sin(value))-cos(value)-x+1,x)
    return math.ceil(truncate(ans[0], 14))


# In[8]:


findn(0.5)
print(findn(0.5))


# In[9]:


findn(0.7)
print(findn(0.7))


# In[10]:


findn(0.9)
print(findn(0.9))


# In[11]:


findn(0.999)
print(findn(0.999))


# In[12]:


findn(0.9999)
print(findn(0.9999))


# In[13]:


findn(1)
print(findn(1))


# In[15]:


time.sleep(6.2)


# In[ ]:




