#!/usr/bin/env python
# coding: utf-8

# In[2]:


from sympy.solvers import solve,nsolve,solveset
from sympy import Symbol,symbols,sin,pi,cos
import numpy as np
import math


# In[3]:


from matplotlib import pyplot as plt 


# In[4]:


def alpha(n):
    x = Symbol('x')
    return solve((n*sin(x))-cos(x)-n+1,x)


# In[5]:


def area_ratio(n):
    value=alpha(n)[0]
    return ((1-cos(value)+sin(value)-value)/((4-(float(pi)))/2))


# In[6]:


x=np.arange(1,100,1)
y=x


# In[7]:


y=list(map(area_ratio,x))


# In[9]:


plt.plot(x,y)
plt.xlabel('n')
plt.ylabel('Area Ratio')
plt.show()

