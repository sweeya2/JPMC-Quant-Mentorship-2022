#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import norm
import math


# In[2]:


def getd1(St, t):
    return np.divide((np.log(St/50.0) + (0.12 + (0.3*0.3)/2.0)*(1.0-t)),(0.3*math.sqrt(1.0 - t)))


# In[3]:


def getd2(St, t):
    return getd1(St, t) - (0.3*math.sqrt(1.0-t))


# In[4]:


def put_price(St, t):
    return norm.cdf(- getd2(St, t)) * 50.0 * math.exp(-0.12 *(1.0 - t)) - norm.cdf(- getd1(St, t))*St


# In[5]:


x=np.arange(1,101,1)
y=x


# In[6]:


y = put_price(x, 0.0)


# In[7]:


plt.plot(x,y)
plt.xlabel('Stock Price ($)')
plt.ylabel('BSM_price_put_t=0')
plt.show()


# In[8]:


y = put_price(x, 0.5)


# In[9]:


plt.plot(x,y)
plt.xlabel('Stock Price ($)')
plt.ylabel('BSM_price_put_t=0.5')
plt.show()


# In[10]:


y = put_price(x, 0.999999999)


# In[11]:


plt.plot(x,y)
plt.xlabel('Stock Price ($)')
plt.ylabel('BSM_price_put_t=1')
plt.show()

