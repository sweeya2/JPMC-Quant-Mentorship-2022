#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import norm
import math
import time


# In[23]:


def getd1(St, t):
    return (np.log(St/50.0) + (0.12 + (0.3*0.3)/2.0)*(1.0-t))/(0.3*math.sqrt(1.0 - t))


# In[24]:


def getd2(St, t):
    return getd1(St, t) - (0.3*math.sqrt(1.0-t))


# In[25]:


def call_price(St, t):
    return norm.cdf(getd1(St, t))*St - norm.cdf(getd2(St, t)) * 50.0 * math.exp(-0.12 *(1.0 - t))


# In[26]:


def delta_call(St,t):
    return(call_price(St+0.000001,t)-call_price(St,t))/0.000001;


# In[35]:


print("delta_call(125, 0.0):")
print(delta_call(125, 0.0))


# In[28]:


print("delta_call(125, 0.5):")
print(delta_call(125, 0.5))


# In[30]:


print("delta_call(125, 0.999999):")
print(delta_call(125, 0.999999))


# In[32]:


def put_price(St, t):
    return norm.cdf(- getd2(St, t)) * 50.0 * math.exp(-0.12 *(1.0 - t)) - norm.cdf(- getd1(St, t))*St


# In[33]:


def delta_put(St,t):
    return(put_price(St+0.000001,t)-put_price(St,t))/0.000001;


# In[11]:


print("delta_put(125, 0.0):")
print(delta_put(125, 0.0))


# In[12]:


print("delta_put(125, 0.5):")
print(delta_put(125, 0.5))


# In[34]:


print("delta_put(125, 0.99999):")
print(delta_put(125, 0.99999))


# In[ ]:


time.sleep(6.2)

